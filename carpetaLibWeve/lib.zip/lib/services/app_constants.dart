class AppConstants {
  static const String mapboxAccessToken =
      "pk.eyJ1IjoidnVsbGV0aWNldiIsImEiOiJjbDZ3YWx6Z2syY2VnM3BvYWZocnNjY3M5In0.jVRfwlWiTltfmcagTBo6nQ";
  static const String mapBoxStyleId =
      "https://api.mapbox.com/styles/v1/vulleticev/cl74ss40u000014lbjp1udy3d/tiles/256/{z}/{x}/{y}@2x?access_token=pk.eyJ1IjoidnVsbGV0aWNldiIsImEiOiJjbDZ3YWx6Z2syY2VnM3BvYWZocnNjY3M5In0.jVRfwlWiTltfmcagTBo6nQ";
  static const String googleMapsApiKey =
      "AIzaSyDY4veWdlfwhq0k8_q7udGIEHWmK9uHsOI";
}
