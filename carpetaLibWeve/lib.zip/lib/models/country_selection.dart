class CountrySelection {
  CountrySelection({
    required this.flagString,
    required this.phoneCode,
  });

  String flagString;
  String phoneCode;
}
